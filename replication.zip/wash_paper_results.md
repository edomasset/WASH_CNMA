---
title: "Results of the paper Effectiveness and Sequencing of Water, Sanitation, and Hygiene interventions to reduce mortality: a multicomponent networkk meta-analysis"
author: "Edoardo Masset"
date: "2025-07-06"
output:
  html_document:
    number_sections: yes
    keep_md: yes
bibliography: library.bib
header-includes: \usepackage{booktabs}
csl: apa.csl
---




This document reproduces all results included in the paper. We import the data from a stata file (**netwashforR_paper.dta**). The data file includes all the studies set up for a network meta-analysis (after including all implicit comparisons). In the datafile, the studies are classified into four intervention categories: 

* WAS: water supply
* WAT: water treatement
* HYG: hygiene 
* SAN: sanitation


We run a random effect network meta-analysis using the package **netmeta**. The results are saved in **m.netmeta_wash**. The meta-analysis includes confidence intervals and prediction intervals.


```
## 
## Attaching package: 'dplyr'
```

```
## The following objects are masked from 'package:stats':
## 
##     filter, lag
```

```
## The following objects are masked from 'package:base':
## 
##     intersect, setdiff, setequal, union
```

```
## Loading required package: metadat
```

```
## Loading 'meta' package (version 8.0-2).
## Type 'help(meta)' for a brief overview.
```

```
## Loading 'netmeta' package (version 3.2-0).
## Type 'help("netmeta-package")' for a brief overview.
```

```
## Number of studies: k = 30
## Number of pairwise comparisons: m = 50
## Number of treatments: n = 9
## Number of designs: d = 9
## 
## Random effects model
## 
## Treatment estimate (sm = 'OR', comparison: other treatments vs 'control'):
##                 OR            95%-CI     z p-value
## control          .                 .     .       .
## HYG         0.9131 [0.7284;  1.1447] -0.79  0.4306
## HYG+SAN     0.9037 [0.6788;  1.2030] -0.69  0.4878
## SAN         0.8537 [0.6511;  1.1193] -1.14  0.2525
## WAS         0.6177 [0.4260;  0.8957] -2.54  0.0111
## WAS+SAN     0.8519 [0.7054;  1.0289] -1.66  0.0961
## WAT         0.7223 [0.5601;  0.9314] -2.51  0.0121
## WAT+HYG     2.9863 [0.4759; 18.7390]  1.17  0.2430
## WAT+HYG+SAN 0.9832 [0.7747;  1.2477] -0.14  0.8889
## 
## Quantifying heterogeneity / inconsistency:
## tau^2 = 0.0100; tau = 0.0999; I^2 = 8.2% [0.0%; 39.8%]
## 
## Tests of heterogeneity (within designs) and inconsistency (between designs):
##                     Q d.f. p-value
## Total           31.61   29  0.3375
## Within designs  16.02   24  0.8872
## Between designs 15.58    5  0.0081
## 
## Details of network meta-analysis methods:
## - Frequentist graph-theoretical approach
## - DerSimonian-Laird estimator for tau^2
## - Calculation of I^2 based on Q
```

We display the results using a **forest plot**. These are the results of the network meta-analysis using the "full interaction model". The prediction intervals are nearly identical to the confidence intervals and we do not display them in the forest plot.

<img src="images/unnamed-chunk-3-1.png" style="display: block; margin: auto;" />

We then calculate the confidence interval of tau2 by bootstrapping. Since we need to retain all comparisons for each multi-arm trial for the network meta-analysis, we resample studies rather than comparisons. We run 500 replications, which at 6 seconds per network meta-analysis requires nearly 50 minutes to run.



```
## Bootstrap 95% CI for tau^2: [ 0 ,  0.0386 ]
```


We use the outupt of **m.netmeta_wash** to  plot the network graph using **netgraph**.The nodes are well connected.

<img src="images/unnamed-chunk-5-1.png" style="display: block; margin: auto;" />




Next we repeat the exercise after disaggregating all categories, with the exception of water supply (WAS), into the following subcategories:

Water treatment (WAT) is disaggregated into:

* WTC: chlorination 
* WTS: safe storage 
* WTF: filtration 
* WTO: SODIS filtration 

Sanitation (SAN) is disaggregated into:

* SAI: sanitation interventions at the individual level
* SAC: sanitation interventions at the collective level

Hygiene (HYG) is disaggregated into:

* HYS: software intervention
* HYH: hardware intervention
* HYO: soap intervention

We first import the data from a stata datafile which includes all the comparisons disaggregated using the 10 categories above, called **netwashforR_dis_paper**)



We run a random effect network meta-analysis with the disaggregated categories. The meta-analysis calculates confidence intervals and prediction intervals.


```
## Number of studies: k = 28
## Number of pairwise comparisons: m = 50
## Number of treatments: n = 15
## Number of designs: d = 14
## 
## Random effects model
## 
## Treatment estimate (sm = 'OR', comparison: other treatments vs 'control'):
##                 OR            95%-CI     z p-value             95%-PI
## control          .                 .     .       .                  .
## HYH         1.0904 [0.8493;  1.3999]  0.68  0.4973  [0.8370;  1.4204]
## HYO         1.1353 [0.4260;  3.0253]  0.25  0.7997  [0.4025;  3.2026]
## HYS+SAC     0.8782 [0.3923;  1.9656] -0.32  0.7520  [0.3744;  2.0599]
## SAC         0.8980 [0.6937;  1.1624] -0.82  0.4138  [0.6833;  1.1800]
## SAC+HYS     0.9072 [0.7182;  1.1459] -0.82  0.4138  [0.7085;  1.1615]
## WAS         0.6188 [0.4418;  0.8667] -2.79  0.0052  [0.4332;  0.8838]
## WAS+SAI     0.8957 [0.8188;  0.9799] -2.40  0.0163  [0.8146;  0.9850]
## WTC         0.7436 [0.5690;  0.9717] -2.17  0.0300  [0.5602;  0.9870]
## WTC+HYH+SAC 1.0338 [0.8285;  1.2901]  0.29  0.7685  [0.8179;  1.3068]
## WTC+HYO     3.3219 [0.5033; 21.9241]  1.25  0.2124  [0.4511; 24.4654]
## WTC+WTS     1.0434 [0.1465;  7.4329]  0.04  0.9662  [0.1307;  8.3314]
## WTF         1.0390 [0.5136;  2.1020]  0.11  0.9153  [0.4930;  2.1899]
## WTO         0.7676 [0.2018;  2.9202] -0.39  0.6981  [0.1867;  3.1560]
## WTS         0.5161 [0.0467;  5.7077] -0.54  0.5896  [0.0406;  6.5633]
## 
## Quantifying heterogeneity / inconsistency:
## tau^2 = 0; tau = 0; I^2 = 0% [0.0%; 45.4%]
## 
## Tests of heterogeneity (within designs) and inconsistency (between designs):
##                     Q d.f. p-value
## Total           21.84   22  0.4695
## Within designs  10.15   17  0.8971
## Between designs 11.69    5  0.0393
## 
## Details of network meta-analysis methods:
## - Frequentist graph-theoretical approach
## - DerSimonian-Laird estimator for tau^2
## - Calculation of I^2 based on Q
```

We illustrate the results of the network meta-analysis using a forest plot. We do not display prediction intervals, because they are nearly identical to the confidence intervals.

<img src="images/unnamed-chunk-8-1.png" style="display: block; margin: auto;" />

We then calculate the confidence interval of tau2 by bootstrapping. 



```
## Bootstrap 95% CI for tau^2: [ 0 ,  0.0059 ]
```


We build a network graph.

<img src="images/unnamed-chunk-10-1.png" style="display: block; margin: auto;" />




We conduct subgroup analysis to see whether the results differ depending on the water and sanitation initial conditions. We use the original four interventions categories and the WHO/UNICEF definition of improved/unimproved water and sanitation conditions

First we compare the estimates under different water initial conditions. To do this we use the data disaggregated by initial water conditions in the stata file **netwashforRH_w_paper.dta**.



We run a network meta-analysis separately for improved and unimproved water initial conditions.







We plot the forest plots on the same chart in order to compare the results under the different initial water conditions.


``` r
library(ggplot2)
library(ggtext)
library(grid)

# Combine netmeta objects
comp <- netbind(
  m.netmeta_wash_imp, m.netmeta_wash_nimp,
  name = c("improved sanitation", "not improved"),
  col.study = c("red", "black"),
  col.square = c("red", "black")
)

# Convert to data frame
sum_df <- as.data.frame(comp$random)
sum_df <- subset(sum_df, treat != "control")

# Add k and N
sum_df$k <- c(7, 1, 1, 2, 4, 4, 2, 3, 1, 2, 8, 1, 1)
sum_df$N <- c(33382, 3880, 2086, 3852, 9168, 5595, 4038, 4641, 3984, 9319, 7391, 361, 3834)[1:nrow(sum_df)]

# Labeling and grouping
sum_df$sanitation <- ifelse(sum_df$name == "improved sanitation", "Improved", "Not improved")
sum_df$color <- ifelse(sum_df$sanitation == "Improved", "black", "red")
sum_df$treat_display <- paste(sum_df$treat, sum_df$sanitation)
sum_df$label_left <- paste0("k = ", sum_df$k, ", N = ", sum_df$N)

# Order treatments
treatments <- unique(sum_df$treat)
ordered_labels <- unlist(lapply(treatments, function(t) {
  c(paste(t, "Improved"), paste(t, "Not improved"))
}))
sum_df$treat_display <- factor(sum_df$treat_display, levels = rev(ordered_labels))

# OR label
sum_df$label <- sprintf("OR = %.2f (%.2f–%.2f)", exp(sum_df$TE), exp(sum_df$lower), exp(sum_df$upper))

# Bold treatment in markdown
levels(sum_df$treat_display) <- sapply(levels(sum_df$treat_display), function(lbl) {
  parts <- strsplit(lbl, " ")[[1]]
  treatment <- parts[1]
  rest <- paste(parts[-1], collapse = " ")
  paste0("**", treatment, "** ", rest)
})

# Log-scale values
sum_df$lower_exp <- exp(sum_df$lower)
sum_df$upper_exp <- exp(sum_df$upper)

# Clip and truncate CIs
clip_limit <- 10
arrow_start <- clip_limit - 4.7  # Where CI stops
arrow_end <- clip_limit - 4.2    # Where arrow points
x_max <- max(clip_limit, exp(sum_df$upper)) * 1.05

sum_df$clipped <- sum_df$upper_exp > clip_limit
sum_df$upper_clip <- ifelse(sum_df$clipped, arrow_start, sum_df$upper_exp)

# Plot
ggplot(sum_df, aes(y = treat_display, color = color)) +
  geom_errorbarh(aes(xmin = lower_exp, xmax = upper_clip), height = 0.2) +
  geom_segment(
    data = subset(sum_df, clipped),
    aes(x = arrow_start, xend = arrow_end, yend = treat_display),
    arrow = arrow(length = unit(0.15, "cm"), ends = "last", type = "closed"),
    inherit.aes = TRUE
  ) +
  geom_point(aes(x = exp(TE)), shape = 15, size = 3) +
  geom_text(aes(x = x_max * 0.95, label = label), hjust = 1, size = 3, color = "black") +
  geom_text(aes(x = 0.1, label = label_left), hjust = 0, size = 3, color = "black") +
  geom_vline(xintercept = 1, linetype = "dashed") +
  scale_x_log10(limits = c(0.1, x_max)) +
  scale_color_identity() +
  theme_minimal(base_size = 10) +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    axis.text.y = element_markdown(hjust = 0),
    legend.position = "none"
  ) +
  labs(
    title = "Forest Plot of WASH Interventions by Water Status",
    x = NULL,
    y = NULL
  ) +
  annotate("text", x = 0.3, y = 0.5, label = "Favours WASH", hjust = 0, size = 3.5, vjust = 0.1) +
  annotate("text", x = 1.5, y = 0.5, label = "Favours Control", hjust = 0, size = 3.5, vjust = 0.1)
```

![](images/unnamed-chunk-14-1.png)<!-- -->


We then calculate the confidence interval of tau2 by bootstrapping. 



```
## Bootstrap 95% CI for tau^2: [ 0 ,  0 ]
```

We then calculate the confidence interval of tau2 by bootstrapping. 



```
## Bootstrap 95% CI for tau^2: [ 0 ,  0.217 ]
```



Second we compare the estimates under different saniation initial conditions. To do this we use the data disaggregated by initial sanitation conditions in the stata file **netwashforRH_s_paper.dta**.


We run separate meta-analysis under improved and unimproved sanitation initial conditions.





``` r
library(ggplot2)
library(ggtext)
library(grid)

# Combine netmeta objects
comp <- netbind(
  m.netmeta_wash_imps, m.netmeta_wash_nimps,
  name = c("improved sanitation", "not improved"),
  col.study = c("red", "black"),
  col.square = c("red", "black")
)

# Convert to data frame
sum_df <- as.data.frame(comp$random)
sum_df <- subset(sum_df, treat != "control")

# Add k and N
sum_df$k <- c(4, 1, 2, 3, 1, 1, 6, 2, 2, 1, 11, 1, 2)
sum_df$N <- c(7312, 2086, 3852, 5867,20875, 2082, 30711, 7864, 9319, 3301, 10899, 361, 5790)[1:nrow(sum_df)]

# Labeling and grouping
sum_df$sanitation <- ifelse(sum_df$name == "improved sanitation", "Improved", "Not improved")
sum_df$color <- ifelse(sum_df$sanitation == "Improved", "black", "red")
sum_df$treat_display <- paste(sum_df$treat, sum_df$sanitation)
sum_df$label_left <- paste0("k = ", sum_df$k, ", N = ", sum_df$N)

# Order treatments
treatments <- unique(sum_df$treat)
ordered_labels <- unlist(lapply(treatments, function(t) {
  c(paste(t, "Improved"), paste(t, "Not improved"))
}))
sum_df$treat_display <- factor(sum_df$treat_display, levels = rev(ordered_labels))

# OR label
sum_df$label <- sprintf("OR = %.2f (%.2f–%.2f)", exp(sum_df$TE), exp(sum_df$lower), exp(sum_df$upper))

# Bold treatment in markdown
levels(sum_df$treat_display) <- sapply(levels(sum_df$treat_display), function(lbl) {
  parts <- strsplit(lbl, " ")[[1]]
  treatment <- parts[1]
  rest <- paste(parts[-1], collapse = " ")
  paste0("**", treatment, "** ", rest)
})

# Log-scale values
sum_df$lower_exp <- exp(sum_df$lower)
sum_df$upper_exp <- exp(sum_df$upper)

# Clip and truncate CIs
clip_limit <- 10
arrow_start <- clip_limit - 5.7  # Where CI stops
arrow_end <- clip_limit - 5.2    # Where arrow points
x_max <- max(clip_limit, exp(sum_df$upper)) * 1.05

sum_df$clipped <- sum_df$upper_exp > clip_limit
sum_df$upper_clip <- ifelse(sum_df$clipped, arrow_start, sum_df$upper_exp)

# Plot
ggplot(sum_df, aes(y = treat_display, color = color)) +
  geom_errorbarh(aes(xmin = lower_exp, xmax = upper_clip), height = 0.2) +
  geom_segment(
    data = subset(sum_df, clipped),
    aes(x = arrow_start, xend = arrow_end, yend = treat_display),
    arrow = arrow(length = unit(0.15, "cm"), ends = "last", type = "closed"),
    inherit.aes = TRUE
  ) +
  geom_point(aes(x = exp(TE)), shape = 15, size = 3) +
  geom_text(aes(x = x_max * 0.95, label = label), hjust = 1, size = 3, color = "black") +
  geom_text(aes(x = 0.1, label = label_left), hjust = 0, size = 3, color = "black") +
  geom_vline(xintercept = 1, linetype = "dashed") +
  scale_x_log10(limits = c(0.1, x_max)) +
  scale_color_identity() +
  theme_minimal(base_size = 10) +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    axis.text.y = element_markdown(hjust = 0),
    legend.position = "none"
  ) +
  labs(
    title = "Forest Plot of WASH Interventions by Sanitation Status",
    x = NULL,
    y = NULL
  ) +
  annotate("text", x = 0.3, y = 0.5, label = "Favours WASH", hjust = 0, size = 3.5, vjust = 0.1) +
  annotate("text", x = 1.5, y = 0.5, label = "Favours Control", hjust = 0, size = 3.5, vjust = 0.1)
```

![](images/unnamed-chunk-20-1.png)<!-- -->


We then calculate the confidence interval of tau2 by bootstrapping for improved sanitation conditions. 



```
## Bootstrap 95% CI for tau^2: [ 0 ,  0.0257 ]
```

We then calculate the confidence interval of tau2 by bootstrapping for unimproved sanitation conditions. 



```
## Bootstrap 95% CI for tau^2: [ 0 ,  0.1206 ]
```


Third, we compare the effect sizes obtained by RCTs with those found by quasi-experimental studies. To do this we use the original dataset (**netwashforR_paper.dta**), which includes a dummy variable **rct** for randomised control trials .


We run a network meta-analysis separately for RCTs and qasi-experimental studies.




We plot the combined results in a forest plot.



``` r
library(ggplot2)
library(ggtext)
library(grid)

# Combine netmeta objects
comp <- netbind(
  m.netmeta_wash_rct1, m.netmeta_wash_rct0,
  name = c("RCT", "QED"),
  col.study = c("red", "black"),
  col.square = c("red", "black")
)

# Convert to data frame
sum_df <- as.data.frame(comp$random)
sum_df <- subset(sum_df, treat != "control")

# Add k and N
sum_df$k <- c(7, 2, 3, 12, 1, 3, 3, 2, 4)
sum_df$N <- c(13485, 7864, 11405, 12986, 361, 7872, 24538, 3852, 9168)[1:nrow(sum_df)]

# Labeling and grouping
sum_df$sanitation <- ifelse(sum_df$name == "RCT", "RCT", "QED")
sum_df$color <- ifelse(sum_df$sanitation == "RCT", "black", "red")
sum_df$treat_display <- paste(sum_df$treat, sum_df$sanitation)
sum_df$label_left <- paste0("k = ", sum_df$k, ", N = ", sum_df$N)

# Order treatments
treatments <- unique(sum_df$treat)
ordered_labels <- unlist(lapply(treatments, function(t) {
  c(paste(t, "RCT"), paste(t, "QED"))
}))
sum_df$treat_display <- factor(sum_df$treat_display, levels = rev(ordered_labels))

# OR label
sum_df$label <- sprintf("OR = %.2f (%.2f–%.2f)", exp(sum_df$TE), exp(sum_df$lower), exp(sum_df$upper))

# Bold treatment in markdown
levels(sum_df$treat_display) <- sapply(levels(sum_df$treat_display), function(lbl) {
  parts <- strsplit(lbl, " ")[[1]]
  treatment <- parts[1]
  rest <- paste(parts[-1], collapse = " ")
  paste0("**", treatment, "** ", rest)
})

# Log-scale values
sum_df$lower_exp <- exp(sum_df$lower)
sum_df$upper_exp <- exp(sum_df$upper)

# Clip and truncate CIs
clip_limit <- 10
arrow_start <- clip_limit - 5.7  # Where CI stops
arrow_end <- clip_limit - 5.2    # Where arrow points
x_max <- max(clip_limit, exp(sum_df$upper)) * 1.05

sum_df$clipped <- sum_df$upper_exp > clip_limit
sum_df$upper_clip <- ifelse(sum_df$clipped, arrow_start, sum_df$upper_exp)

# Plot
ggplot(sum_df, aes(y = treat_display, color = color)) +
  geom_errorbarh(aes(xmin = lower_exp, xmax = upper_clip), height = 0.2) +
  geom_segment(
    data = subset(sum_df, clipped),
    aes(x = arrow_start, xend = arrow_end, yend = treat_display),
    arrow = arrow(length = unit(0.15, "cm"), ends = "last", type = "closed"),
    inherit.aes = TRUE
  ) +
  geom_point(aes(x = exp(TE)), shape = 15, size = 3) +
  geom_text(aes(x = x_max * 0.95, label = label), hjust = 1, size = 3, color = "black") +
  geom_text(aes(x = 0.1, label = label_left), hjust = 0, size = 3, color = "black") +
  geom_vline(xintercept = 1, linetype = "dashed") +
  scale_x_log10(limits = c(0.1, x_max)) +
  scale_color_identity() +
  theme_minimal(base_size = 10) +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    axis.text.y = element_markdown(hjust = 0),
    legend.position = "none"
  ) +
  labs(
    title = "Forest Plot of WASH Interventions by Study Design",
    x = NULL,
    y = NULL
  ) +
  annotate("text", x = 0.3, y = 0.5, label = "Favours WASH", hjust = 0, size = 3.5, vjust = 0.1) +
  annotate("text", x = 1.5, y = 0.5, label = "Favours Control", hjust = 0, size = 3.5, vjust = 0.1)
```

![](images/unnamed-chunk-26-1.png)<!-- -->


We then calculate the confidence interval of tau2 by bootstrapping for RCTs. 


```
## Bootstrap 95% CI for tau^2: [ 0 ,  0.0322 ]
```


We then calculate the confidence interval of tau2 by bootstrapping for QEDs. 


```
## Bootstrap 95% CI for tau^2: [ 0 ,  0.0164 ]
```


Next we estimate the additive model and the partial interaction model. The code and the procedure for the selection of the best partial interaction model are too long to be reported here, and are included in another markdown file called **interactions.Rmd**, which describe the procedure and reports the output. Here we report the key results in a table (built using the file **res_nma_w.csv**) that was built after reading the results from the output of **interactions.Rmd**.


<table class=" lightable-classic" style="color: black; font-family: Cambria; width: auto !important; margin-left: auto; margin-right: auto;">
<caption><b> &lt;</b></caption>
 <thead>
<tr>
<th style="empty-cells: hide;" colspan="1"></th>
<th style="padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="2"><div style="border-bottom: 1px solid #111111; margin-bottom: -1px; ">Full interaction model</div></th>
<th style="padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="2"><div style="border-bottom: 1px solid #111111; margin-bottom: -1px; ">Additive model</div></th>
<th style="padding-bottom:0; padding-left:3px;padding-right:3px;text-align: center; " colspan="2"><div style="border-bottom: 1px solid #111111; margin-bottom: -1px; ">Partial interaction model</div></th>
</tr>
  <tr>
   <th style="text-align:left;"> Interventions </th>
   <th style="text-align:right;"> Coeff. </th>
   <th style="text-align:right;"> Z-value </th>
   <th style="text-align:right;"> Coeff. </th>
   <th style="text-align:right;"> Z-value </th>
   <th style="text-align:right;"> Coeff. </th>
   <th style="text-align:right;"> Z-value </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> Water supply </td>
   <td style="text-align:right;"> 0.62 </td>
   <td style="text-align:right;"> -2.79 </td>
   <td style="text-align:right;"> 0.84 </td>
   <td style="text-align:right;"> -2.20 </td>
   <td style="text-align:right;"> 0.62 </td>
   <td style="text-align:right;"> -2.79 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Water treatment </td>
   <td style="text-align:right;"> 0.72 </td>
   <td style="text-align:right;"> -2.67 </td>
   <td style="text-align:right;"> 0.91 </td>
   <td style="text-align:right;"> 1.14 </td>
   <td style="text-align:right;"> 0.76 </td>
   <td style="text-align:right;"> -2.41 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Hygiene </td>
   <td style="text-align:right;"> 0.92 </td>
   <td style="text-align:right;"> -0.81 </td>
   <td style="text-align:right;"> 1.00 </td>
   <td style="text-align:right;"> 0.05 </td>
   <td style="text-align:right;"> 0.97 </td>
   <td style="text-align:right;"> -0.39 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Sanitation </td>
   <td style="text-align:right;"> 0.85 </td>
   <td style="text-align:right;"> -1.31 </td>
   <td style="text-align:right;"> 1.05 </td>
   <td style="text-align:right;"> 0.65 </td>
   <td style="text-align:right;"> 0.90 </td>
   <td style="text-align:right;"> -1.18 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Interactions </td>
   <td style="text-align:right;">  </td>
   <td style="text-align:right;">  </td>
   <td style="text-align:right;">  </td>
   <td style="text-align:right;">  </td>
   <td style="text-align:right;">  </td>
   <td style="text-align:right;">  </td>
  </tr>
  <tr>
   <td style="text-align:left;"> WAS+SAN </td>
   <td style="text-align:right;"> 1.71 </td>
   <td style="text-align:right;"> 2.45 </td>
   <td style="text-align:right;">  </td>
   <td style="text-align:right;">  </td>
   <td style="text-align:right;"> 1.60 </td>
   <td style="text-align:right;"> 2.39 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> WAT+HYG </td>
   <td style="text-align:right;"> 4.50 </td>
   <td style="text-align:right;"> 1.60 </td>
   <td style="text-align:right;">  </td>
   <td style="text-align:right;">  </td>
   <td style="text-align:right;">  </td>
   <td style="text-align:right;">  </td>
  </tr>
  <tr>
   <td style="text-align:left;"> HYG+SAN </td>
   <td style="text-align:right;"> 1.16 </td>
   <td style="text-align:right;"> 0.68 </td>
   <td style="text-align:right;">  </td>
   <td style="text-align:right;">  </td>
   <td style="text-align:right;">  </td>
   <td style="text-align:right;">  </td>
  </tr>
  <tr>
   <td style="text-align:left;"> WAT+HYG+SAN </td>
   <td style="text-align:right;"> 1.75 </td>
   <td style="text-align:right;"> 2.38 </td>
   <td style="text-align:right;">  </td>
   <td style="text-align:right;">  </td>
   <td style="text-align:right;"> 1.53 </td>
   <td style="text-align:right;"> 2.53 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Q </td>
   <td style="text-align:right;"> 31.61 </td>
   <td style="text-align:right;">  </td>
   <td style="text-align:right;"> 44.82 </td>
   <td style="text-align:right;">  </td>
   <td style="text-align:right;"> 34.46 </td>
   <td style="text-align:right;">  </td>
  </tr>
  <tr>
   <td style="text-align:left;"> tau </td>
   <td style="text-align:right;"> 0.01 </td>
   <td style="text-align:right;">  </td>
   <td style="text-align:right;"> 0.03 </td>
   <td style="text-align:right;">  </td>
   <td style="text-align:right;"> 0.01 </td>
   <td style="text-align:right;">  </td>
  </tr>
</tbody>
</table>


```
## Number of studies: k = 30
## Number of pairwise comparisons: m = 50
## Number of treatments: n = 9
## Number of active components: c = 4
## Number of designs: d = 9
## 
## Common effects model (inactive component: 'control')
## 
## Treatment estimate (sm = 'OR', comparison: other treatments vs 'control'):
##                 OR           95%-CI     z p-value
## control          .                .     .       .
## HYG         1.0035 [0.8707; 1.1566]  0.05  0.9612
## HYG+SAN     1.0522 [0.9063; 1.2216]  0.67  0.5040
## SAN         1.0485 [0.9086; 1.2099]  0.65  0.5166
## WAS         0.8362 [0.7130; 0.9807] -2.20  0.0278
## WAS+SAN     0.8768 [0.8035; 0.9568] -2.95  0.0032
## WAT         0.9078 [0.7690; 1.0717] -1.14  0.2535
## WAT+HYG     0.9111 [0.7438; 1.1160] -0.90  0.3682
## WAT+HYG+SAN 0.9553 [0.7912; 1.1533] -0.48  0.6340
## 
## Incremental effect for existing combinations:
##                iOR           95%-CI     z p-value
## HYG+SAN     1.0522 [0.9063; 1.2216]  0.67  0.5040
## WAS+SAN     0.8768 [0.8035; 0.9568] -2.95  0.0032
## WAT+HYG     0.9111 [0.7438; 1.1160] -0.90  0.3682
## WAT+HYG+SAN 0.9553 [0.7912; 1.1533] -0.48  0.6340
## 
## Incremental effect for components:
##        iOR           95%-CI     z p-value
## HYG 1.0035 [0.8707; 1.1566]  0.05  0.9612
## SAN 1.0485 [0.9086; 1.2099]  0.65  0.5166
## WAS 0.8362 [0.7130; 0.9807] -2.20  0.0278
## WAT 0.9078 [0.7690; 1.0717] -1.14  0.2535
## 
## Quantifying heterogeneity / inconsistency:
## tau^2 = 0.0318; tau = 0.1784; I^2 = 26.4% [0.0%; 52.0%]
## 
## Heterogeneity statistics:
##                    Q df p-value
## Additive model 44.82 33  0.0823
## Standard model 31.61 29  0.3375
## Difference     13.21  4  0.0103
## 
## Details of network meta-analysis methods:
## - Frequentist graph-theoretical approach
## - Component network meta-analysis
## - DerSimonian-Laird estimator for tau^2
## - Calculation of I^2 based on Q
```

We then calculate the confidence interval of tau2 by bootstrapping. 


```
## Bootstrap 95% CI for tau^2: [ 0 ,  0.0719 ]
```


``` r
addmc_w = netcomb(netmeta_w, inactive = "control")
C2_i= cbind(addmc_w$C.matrix, x = 0)
colnames(C2_i)[5] <- "WAS+SAN"
C2_i["WAS+SAN", "WAS+SAN"] <- 1
C2_i= cbind(C2_i, x = 0)
colnames(C2_i)[6] <- "WAT+HYG+SAN"
C2_i["WAT+HYG+SAN", "WAT+HYG+SAN"] <- 1
admc_w_C2_i <- netcomb(netmeta_w, C.matrix = C2_i, inactive = "control")
admc_w_C2_i
```

```
## Number of studies: k = 30
## Number of pairwise comparisons: m = 30
## Number of treatments: n = 7
## Number of active components: c = 6
## Number of designs: d = 6
## 
## Common effects model (inactive component: 'control')
## 
## Treatment estimate (sm = 'OR', comparison: other treatments vs 'control'):
##                 OR           95%-CI     z p-value
## control          .                .     .       .
## HYG         0.5909 [0.4209; 0.8297] -3.04  0.0024
## SAN         1.4744 [1.0218; 2.1274]  2.08  0.0380
## WAS         0.6101 [0.4607; 0.8079] -3.45  0.0006
## WAS+SAN     0.8975 [0.8202; 0.9820] -2.36  0.0185
## WAT         0.9531 [0.6066; 1.4975] -0.21  0.8348
## WAT+HYG+SAN 0.9641 [0.6445; 1.4422] -0.18  0.8587
## 
## Incremental effect for existing combinations:
##                iOR           95%-CI     z p-value
## WAS+SAN     0.8975 [0.8202; 0.9820] -2.36  0.0185
## WAT+HYG+SAN 0.9641 [0.6445; 1.4422] -0.18  0.8587
## 
## Incremental effect for components:
##                iOR           95%-CI     z p-value
## HYG         0.5909 [0.4209; 0.8297] -3.04  0.0024
## SAN         1.4744 [1.0218; 2.1274]  2.08  0.0380
## WAS         0.6101 [0.4607; 0.8079] -3.45  0.0006
## WAT         0.9531 [0.6066; 1.4975] -0.21  0.8348
## WAS+SAN     0.9977 [0.6232; 1.5972] -0.01  0.9923
## WAT+HYG+SAN 1.1611 [0.5297; 2.5451]  0.37  0.7092
## 
## Quantifying heterogeneity / inconsistency:
## tau^2 = 0; tau = 0; I^2 = 0% [0.0%; 43.9%]
## 
## Heterogeneity statistics:
##                    Q df p-value
## Additive model 12.86 24  0.9684
## Standard model 12.86 24  0.9684
## Difference      0.00  0      --
## 
## Details of network meta-analysis methods:
## - Frequentist graph-theoretical approach
## - Component network meta-analysis
## - DerSimonian-Laird estimator for tau^2
## - Calculation of I^2 based on Q
```


We then calculate the confidence interval of tau2 by bootstrapping. Note that when resampling the model with interactions, we are sometimes applying a model that it is not supported by the data because the interactions are not possible given the sampled data. We therefore set the routine to ignore samples for which the model fails to compute.


```
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
## Warning: The following components are not uniquely identifiable as they always
## appear together in a treatment: 'WAS + WAS+SAN'. The combined effect of these
## components is identifiable by creating a combined component.
```

```
## Bootstrap 95% CI for tau^2: [ 0 ,  0.0475 ]
```

The validity of a network meta-analysis relies on the hypothesis of coherence, or consistency. The analysis assumes that direct and indirect comparisons are identical or in some agreement. Since studies are implemented in different ways in different contexts, this is unlikely to be the case. Since the circumstances of implementation differ from study to study, the direct and indirect effect may differ to the extent that the impact of the interventions are mediated by these circumstances. 

There are two approaches to check consistency. One approach evaluates the overall consistency in the network. A second approach evaluates consistency one comparison at a time.

The first approach is used in the design-by-treatment random effect interaction model (Higgins, 2012). The design-by-treatment model produces a value of $Q$ which is tested against a chi-square distribution. In our application, the value of $Q$ between designs has the same size than the one obtained using a fixed effect model and it fails the inconsistency test at the conventional 5% of statistical significance (Q=15.58, P-value=0.01), which suggests the presence of global inconsistency in the network.


```
## Q statistics to assess homogeneity / consistency
## 
##                     Q df p-value
## Total           27.17 27  0.4547
## Within designs  12.24 24  0.9771
## Between designs 14.93  3  0.0019
## 
## Design-specific decomposition of within-designs Q statistic
## 
##              Design    Q df p-value
##  control vs WAS+SAN 6.83  6  0.3366
##      control vs WAT 2.11  7  0.9537
##      control vs HYG 3.30 11  0.9862
## 
## Between-designs Q statistic after detaching of single designs
## (influential designs have p-value markedly different from 0.0019)
## 
##         Detached design     Q df p-value
##          control vs HYG  3.94  2  0.1391
##          control vs WAT 13.63  2  0.0011
##  control vs WAT+HYG+SAN 14.75  2  0.0006
## 
## Q statistic to assess consistency under the assumption of
## a full design-by-treatment interaction random effects model
## 
##                     Q df p-value tau.within tau2.within
## Between designs 14.93  3  0.0019          0           0
```
In the second approach we compare direct and indirect estimates for those comparisons for which direct comparisons are available. This is called the "net-splitting" method. The differences are tested and a Z-value and a p-value calculated. There are issues of statistical power in conducting this exercise. The absence of statistical significance does not mean absence of a difference, while some statistically significant difference could be the result of chance. But large differences for many comparisons are evidence of network inconsistency. 


```
## Separate indirect from direct evidence (SIDE) using back-calculation method
## 
## Random effects model: 
## 
##              comparison  k prop    nma direct indir.    RoR     z p-value
##          HYG vs control 13 0.93 0.7552 0.7651 0.6271 1.2200  0.48  0.6315
##          SAN vs control  1 0.75 0.6515 0.9075 0.2433 3.7304  3.23  0.0012
##          WAT vs control  9 0.84 0.5391 0.6417 0.2127 3.0170  2.58  0.0098
##  WAT+HYG+SAN vs control  2 0.87 0.8985 1.0775 0.2593 4.1551  3.69  0.0002
##              HYG vs SAN  1 0.87 1.1591 1.4363 0.2902 4.9498  3.04  0.0023
##              HYG vs WAT  1 0.70 1.4008 1.5889 1.0449 1.5206  1.17  0.2414
##      HYG vs WAT+HYG+SAN  1 0.63 0.8405 1.1075 0.5272 2.1006  2.48  0.0133
##              SAN vs WAT  1 0.90 1.2086 1.1062 2.6052 0.4246 -1.32  0.1852
##      SAN vs WAT+HYG+SAN  1 0.90 0.7251 0.7711 0.4106 1.8781  1.01  0.3114
##      WAT vs WAT+HYG+SAN  1 0.76 0.6000 0.6971 0.3762 1.8529  1.54  0.1246
## 
## Legend:
##  comparison - Treatment comparison
##  k          - Number of studies providing direct evidence
##  prop       - Direct evidence proportion
##  nma        - Estimated treatment effect (OR) in network meta-analysis
##  direct     - Estimated treatment effect (OR) derived from direct evidence
##  indir.     - Estimated treatment effect (OR) derived from indirect evidence
##  RoR        - Ratio of Ratios (direct versus indirect)
##  z          - z-value of test for disagreement (direct versus indirect)
##  p-value    - p-value of test for disagreement (direct versus indirect)
```




We report the results of the comparisons more compactly in a table built using the file **netsplit.csv**. Two out of 12 comparisons are statistically different at the 5% significance level. This is more than you would expect by chance but not much more.

<table class=" lightable-classic" style="color: black; font-family: Cambria; width: auto !important; margin-left: auto; margin-right: auto;">
<caption><b>Direct and indirect estimates</b></caption>
 <thead>
  <tr>
   <th style="text-align:left;"> comparison </th>
   <th style="text-align:right;"> k </th>
   <th style="text-align:right;"> nma </th>
   <th style="text-align:right;"> direct </th>
   <th style="text-align:right;"> indirect </th>
   <th style="text-align:right;"> st. error </th>
   <th style="text-align:right;"> z-value </th>
   <th style="text-align:right;"> p-value </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> HYG vs control </td>
   <td style="text-align:right;"> 10 </td>
   <td style="text-align:right;"> 0.9131 </td>
   <td style="text-align:right;"> 0.8979 </td>
   <td style="text-align:right;"> 1.0459 </td>
   <td style="text-align:right;"> 0.36 </td>
   <td style="text-align:right;"> -0.41 </td>
   <td style="text-align:right;"> 0.6789 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> SAN vs control </td>
   <td style="text-align:right;"> 3 </td>
   <td style="text-align:right;"> 0.8537 </td>
   <td style="text-align:right;"> 0.9801 </td>
   <td style="text-align:right;"> 0.4283 </td>
   <td style="text-align:right;"> 0.25 </td>
   <td style="text-align:right;"> 2.23 </td>
   <td style="text-align:right;"> 0.0256 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> WAT vs control </td>
   <td style="text-align:right;"> 12 </td>
   <td style="text-align:right;"> 0.7223 </td>
   <td style="text-align:right;"> 0.7546 </td>
   <td style="text-align:right;"> 0.5334 </td>
   <td style="text-align:right;"> 0.25 </td>
   <td style="text-align:right;"> 0.89 </td>
   <td style="text-align:right;"> 0.3742 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> WAT+HYG vs control </td>
   <td style="text-align:right;"> 1 </td>
   <td style="text-align:right;"> 2.9863 </td>
   <td style="text-align:right;"> 7.1986 </td>
   <td style="text-align:right;"> 0.2058 </td>
   <td style="text-align:right;"> 4.26 </td>
   <td style="text-align:right;"> 1.64 </td>
   <td style="text-align:right;"> 0.1016 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> WAT+HYG+SAN vs control </td>
   <td style="text-align:right;"> 3 </td>
   <td style="text-align:right;"> 0.9832 </td>
   <td style="text-align:right;"> 1.0467 </td>
   <td style="text-align:right;"> 0.6511 </td>
   <td style="text-align:right;"> 0.30 </td>
   <td style="text-align:right;"> 1.32 </td>
   <td style="text-align:right;"> 0.1861 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> HYG vs SAN </td>
   <td style="text-align:right;"> 2 </td>
   <td style="text-align:right;"> 1.0696 </td>
   <td style="text-align:right;"> 1.2815 </td>
   <td style="text-align:right;"> 0.4420 </td>
   <td style="text-align:right;"> 0.31 </td>
   <td style="text-align:right;"> 2.68 </td>
   <td style="text-align:right;"> 0.0075 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> HYG vs WAT </td>
   <td style="text-align:right;"> 2 </td>
   <td style="text-align:right;"> 1.2643 </td>
   <td style="text-align:right;"> 1.3587 </td>
   <td style="text-align:right;"> 0.9962 </td>
   <td style="text-align:right;"> 0.40 </td>
   <td style="text-align:right;"> 0.90 </td>
   <td style="text-align:right;"> 0.3660 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> HYG vs WAT+HYG </td>
   <td style="text-align:right;"> 1 </td>
   <td style="text-align:right;"> 0.3058 </td>
   <td style="text-align:right;"> 0.7688 </td>
   <td style="text-align:right;"> 0.0238 </td>
   <td style="text-align:right;"> 0.45 </td>
   <td style="text-align:right;"> 1.64 </td>
   <td style="text-align:right;"> 0.1016 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> HYG vs WAT+HYG+SAN </td>
   <td style="text-align:right;"> 2 </td>
   <td style="text-align:right;"> 0.9288 </td>
   <td style="text-align:right;"> 1.0448 </td>
   <td style="text-align:right;"> 0.6176 </td>
   <td style="text-align:right;"> 0.27 </td>
   <td style="text-align:right;"> 1.57 </td>
   <td style="text-align:right;"> 0.1171 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> SAN vs WAT </td>
   <td style="text-align:right;"> 2 </td>
   <td style="text-align:right;"> 1.1820 </td>
   <td style="text-align:right;"> 1.0605 </td>
   <td style="text-align:right;"> 2.0916 </td>
   <td style="text-align:right;"> 0.65 </td>
   <td style="text-align:right;"> -1.59 </td>
   <td style="text-align:right;"> 0.1116 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> SAN vs WAT+HYG+SAN </td>
   <td style="text-align:right;"> 2 </td>
   <td style="text-align:right;"> 0.8683 </td>
   <td style="text-align:right;"> 0.8149 </td>
   <td style="text-align:right;"> 1.2569 </td>
   <td style="text-align:right;"> 0.44 </td>
   <td style="text-align:right;"> -1.01 </td>
   <td style="text-align:right;"> 0.3120 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> WAT vs WAT+HYG+SAN </td>
   <td style="text-align:right;"> 2 </td>
   <td style="text-align:right;"> 0.7346 </td>
   <td style="text-align:right;"> 0.7684 </td>
   <td style="text-align:right;"> 0.6177 </td>
   <td style="text-align:right;"> 0.25 </td>
   <td style="text-align:right;"> 0.60 </td>
   <td style="text-align:right;"> 0.5493 </td>
  </tr>
</tbody>
</table>










